#pragma once

#include "registry.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const SubGhzProtocolRegistry subghz_protocol_registry;

typedef struct SubGhzProtocolDecoderBinRAW SubGhzProtocolDecoderBinRAW;

#ifdef __cplusplus
}
#endif
