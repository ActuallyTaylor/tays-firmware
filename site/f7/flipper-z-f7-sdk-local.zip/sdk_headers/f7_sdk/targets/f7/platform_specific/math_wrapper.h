#pragma once
#include <math.h>